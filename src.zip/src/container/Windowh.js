import React from 'react'
import 'react-bootstrap'

function Windowh(){
    return(
        <nav className="navbar navbar-dark " style={{backgroundColor:'rgb(43, 166, 194)'}}>
            <div className="row col-12 d-flex justify-content-center">
            <span className="h3">Chat window</span>
            </div>
        </nav>
    )
}

export default Windowh











